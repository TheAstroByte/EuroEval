# Gate A rerun at 72bd08c5

- The operator notified this Mac that updated tasks were available on the coordination branch. The Mac pulled `acf5e985` and followed the requested Part A rerun in `implementation-notes/2026-11-25-72bd08c5-vllm-metal-wheel.md`. Part B remains excluded.
- Fresh clone at `/Users/daniel/Developer/EuroEval-2310-72bd08c5`, exact commit `72bd08c5cbebbb804f985ee192ffc8bc9b9579a8`. Earlier clones and evidence are preserved.
- `make install` completed on the first attempt in 11.531 seconds with blank prompt answers. The lockfile resolved unchanged. npm's generated package-lock diff was retained and the tracked file restored.
- Setup printed `True` for the requested `_paged_ops.cpython-312-darwin.so` check. Direct URL metadata points to the v0.30.0 GitHub release wheel, not Git.
- The metadata's `archive_info` is empty, so an initial hash-field assertion could not validate a hash there. This was an instrumentation assumption, not a package failure. Verification instead downloaded the exact wheel, checked its SHA-256 against the implementation note, and compared the installed native extension with the wheel member byte for byte. Both checks passed; see `wheel-check.json`. The downloaded wheel itself is excluded from the final handoff archive.
- No `VLLM_METAL_BUILD_FROM_SOURCE=1` or legacy memory-fraction override is used.
- The current Gate A harness and auditor are reused from the immediately preceding Gate A attempt, not Step 0. They use the new RUN directory and current working directory. Footprint calls remain independent of the two-second safety loop and capped at three seconds each. Guard conditions and cancellation cleanup are unchanged.
- A fresh `u.json` was computed once for this attempt: `u=0.5498`. Every direct evaluation in this attempt must use that persisted value.
- Unrelated applications remain intact. Baseline pressure was normal. No live worker or broker claim is authorised in this attempt.
- Each model command is bounded at one hour; overall evaluation work is bounded at three hours before reporting remaining rows unproven. Stop Part A if A1 fails.
- The required pin-rationale paragraph is retained verbatim for the draft comment. Issue posting still requires the operator to approve that draft.
- A1 completed both shot modes and exited 0. Safety result: stop_reason null, peak pressure 1, swap growth 0 MiB, no owned PIDs left. The native-extension startup blocker is resolved for this tested install.
- The A1 log contains no `metal_limit` string. Its default upstream cache-layout path logs the KV budget, not the cap; source excerpts preserve that path and the MLX cap lookup. The literal log criterion is unproven, so A1 is not reported as a full pass and dependent tests are stopped.
- After `Metal worker shutdown complete`, the log reports `Segfault encountered`, with native frames `TVMFFIEnvRegisterCAPI` and `at::accelerator::emptyHostCache()`. The outer CLI still exits 0. The faulting process and native root cause have not been experimentally isolated. A matching `torch.accelerator.empty_host_cache()` call exists at vLLM `distributed/parallel_state.py:2467`; this is a source lead, not a proven localisation.
- No A2-A4 run or A5 feature reproduction was attempted after the unmet A1 gate. No backend patch, environment workaround, implementation commit, or live worker activity was performed.
