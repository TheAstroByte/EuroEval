"""Audit the complete debug completion cache against its logged JSON schema."""
import json
import re
import sys
from jsonschema import Draft202012Validator

log, cache = sys.argv[1], sys.argv[2]
schema = json.loads(re.search(r'Using structured generation with the JSON schema: (.*)', open(log).read())[1])
validator = Draft202012Validator(schema)
rows = json.load(open(cache))
counts = {'unique': len(rows), 'invalid_json': 0, 'schema_violation': 0}
for row in rows.values():
    try:
        value = json.loads(row['sequence'])
    except json.JSONDecodeError:
        counts['invalid_json'] += 1
        continue
    if list(validator.iter_errors(value)):
        counts['schema_violation'] += 1
print(json.dumps(counts))
