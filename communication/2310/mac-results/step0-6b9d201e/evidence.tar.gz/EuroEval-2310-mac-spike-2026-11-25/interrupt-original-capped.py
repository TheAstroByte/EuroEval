"""Send one terminal-style interrupt after observed generation and audit children."""
import datetime as dt
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

root=Path('/tmp/ee-step0')
log=root/'s4-interrupt.log'
command=['/tmp/ee-step0/ee','--model','Qwen/Qwen3-0.6B#no-thinking','--dataset','cnn-dailymail','--gpu-memory-utilization','0.8']
env=dict(os.environ,VLLM_METAL_MEMORY_FRACTION='0.15')
(root/'s4-interrupt.start').write_text(dt.datetime.now(dt.timezone.utc).isoformat())
result={'command':command,'env':{'VLLM_METAL_MEMORY_FRACTION':'0.15'}}

def children_of(pid):
    """Return live process descendants of one owned root process."""
    lines=subprocess.check_output(['ps','-Ao','pid=,ppid=,command='],text=True).splitlines()
    rows={int(m[1]):(int(m[2]),m[3]) for line in lines if (m:=re.match(r'\s*(\d+)\s+(\d+)\s+(.+)',line))}
    owned={pid}
    while True:
        new=owned|{child for child,(parent,_) in rows.items() if parent in owned}
        if new==owned:
            break
        owned=new
    return {child:rows[child][1] for child in owned if child in rows}

with log.open('w') as stream:
    process=subprocess.Popen(command,cwd='/Users/daniel/Developer/EuroEval',env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    result['root_pid']=process.pid
    deadline=time.monotonic()+600
    generation=False
    while process.poll() is None and time.monotonic()<deadline:
        text=log.read_text(errors='replace')
        # Require a nonzero completed prompt count before interrupting.
        if re.search(r'Processed prompts:.*?\|\s*[1-9]\d*/\d+',text):
            generation=True
            break
        time.sleep(1)
    result['generation_observed']=generation
    owned=children_of(process.pid)
    result['owned_before_signal']=owned
    if process.poll() is None:
        result['signal_time']=dt.datetime.now(dt.timezone.utc).isoformat()
        os.killpg(process.pid,signal.SIGINT)
        result['signal']='one SIGINT to owned process group'
    for delay in (5,25):
        time.sleep(delay)
        process.poll()
        rows=subprocess.check_output(['ps','-Ao','pid=,ppid=,command='],text=True)
        survivors=[line for line in rows.splitlines() if re.match(r'\s*(\d+)',line) and int(re.match(r'\s*(\d+)',line)[1]) in owned]
        result['survivors_after_5s' if delay==5 else 'survivors_after_30s']=survivors
    if process.poll() is None:
        result['cleanup']='SIGTERM after 30-second audit'
        os.killpg(process.pid,signal.SIGTERM)
    result['exit']=process.wait(timeout=15)
(root/'s4-interrupt.end').write_text(dt.datetime.now(dt.timezone.utc).isoformat())
(root/'s4-interrupt-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
