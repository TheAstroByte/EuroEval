#!/bin/bash
while true; do
  echo "=== $(date -u +%FT%TZ)"
  vm_stat
  sysctl vm.swapusage
  sysctl -n kern.memorystatus_vm_pressure_level
  ps -Ao pid,ppid,rss,command | grep -E '[e]uroeval|[v]llm|[E]ngineCore'
  sleep 2
done
