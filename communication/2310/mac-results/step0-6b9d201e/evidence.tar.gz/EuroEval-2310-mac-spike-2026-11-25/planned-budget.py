"""Test the planned headroom calculation using the actual Metal fraction control."""
import datetime as dt
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

root=Path('/tmp/ee-step0')
headroom=float(sys.argv[1]) if len(sys.argv)>1 else 1.0
name=f's3-corrected-headroom-{headroom:g}'
vm=subprocess.check_output(['vm_stat'],text=True)
(root/f'{name}-idle.txt').write_text(vm+subprocess.check_output(['sysctl','vm.swapusage'],text=True))
page=int(re.search(r'page size of (\d+) bytes',vm)[1])
free=int(re.search(r'Pages free:\s+(\d+)',vm)[1])
inactive=int(re.search(r'Pages inactive:\s+(\d+)',vm)[1])
available=(free+inactive)*page
total=int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True))
cap=55662788608
usable=min(cap,max(0,available-int(headroom*2**30)))
cli=.8*usable/total
metal=.8*usable/cap
inputs={'headroom_gib':headroom,'host_available_bytes':available,'total_bytes':total,'torch_cap_bytes':cap,'mlx_cap_bytes':cap,'usable_bytes':usable,'planned_cli_util':cli,'corrected_metal_fraction':metal,'note':'Both cap values are the static measured values in s1-versions.txt. CLI util alone is known ineffective. This run explicitly applies the corrected Metal fraction.'}
(root/f'{name}-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(root/f'{name}.start').write_text(dt.datetime.now(dt.timezone.utc).isoformat())
command=['/tmp/ee-step0/ee','--model','Qwen/Qwen3-0.6B#no-thinking','--dataset','sst5','--gpu-memory-utilization',str(cli),'--num-iterations','1']
env=dict(os.environ,VLLM_METAL_MEMORY_FRACTION=str(metal))
result={'command':command,'inputs':inputs}
with (root/f'{name}.log').open('w') as output:
    process=subprocess.Popen(['/usr/bin/time','-l',*command],cwd='/Users/daniel/Developer/EuroEval',env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
    deadline=time.monotonic()+240
    critical=0
    while process.poll() is None and time.monotonic()<deadline:
        pressure=int(subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True))
        critical=critical+1 if pressure==4 else 0
        if critical>=2:
            result['stopped']='critical pressure in two consecutive samples'
            os.killpg(process.pid,signal.SIGINT)
            break
        time.sleep(2)
    if process.poll() is None and time.monotonic()>=deadline:
        result['stopped']='240 second trial limit'
        os.killpg(process.pid,signal.SIGINT)
    try:
        result['exit']=process.wait(timeout=30)
    except subprocess.TimeoutExpired:
        result['cleanup']='SIGTERM after interrupt cleanup timeout'
        os.killpg(process.pid,signal.SIGTERM)
        result['exit']=process.wait(timeout=15)
(root/f'{name}.exit').write_text(str(result['exit'])+'\n')
(root/f'{name}.end').write_text(dt.datetime.now(dt.timezone.utc).isoformat())
(root/f'{name}-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
