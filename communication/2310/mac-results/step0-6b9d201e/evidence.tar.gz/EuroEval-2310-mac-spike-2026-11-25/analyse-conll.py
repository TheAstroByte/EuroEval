"""Count parser failures in the preserved cache and retain concrete examples."""
import json
from pathlib import Path
from euroeval.string_utils import extract_json_dict_from_string

root=Path('/tmp/ee-step0')
x=json.loads((root/'conll-model-outputs.json').read_text())
invalid=[{'cache_key':key,'sequence':value['sequence']} for key,value in x.items() if extract_json_dict_from_string(s=value['sequence']) is None]
output={'cached_unique_sequences':len(x),'invalid_unique_sequences':len(invalid),'note':'Unique cache entries, not the total number of evaluated samples across bootstrap iterations. No tokenizer or model changes.','invalid_examples':invalid[:12]}
(root/'conll-invalid-examples.json').write_text(json.dumps(output,indent=2)+'\n')
print({key:value for key,value in output.items() if key!='invalid_examples'})
