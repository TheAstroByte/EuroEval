#!/bin/bash
cd /Users/daniel/Developer/EuroEval || exit 1
# Use the pre-install idle snapshot so prior swapping does not inflate the budget.
export VLLM_METAL_MEMORY_FRACTION=0.4069843088232221
name=s3-corrected-planned
printf '%s\n' 'Pre-install host_available=27.372589111328125 GiB; cap=51.84001159667969 GiB; total=64 GiB; headroom=1 GiB; usable=26.372589111328125 GiB; CLI util=0.3296573638916016; corrected Metal fraction=0.4069843088232221' > /tmp/ee-step0/s3-planned-inputs.txt
date -u +%FT%TZ > "/tmp/ee-step0/$name.start"
/usr/bin/time -l /tmp/ee-step0/ee --model 'Qwen/Qwen3-0.6B#no-thinking' --dataset sst5 --gpu-memory-utilization 0.3296573638916016 --num-iterations 1 > "/tmp/ee-step0/$name.log" 2>&1
printf '%s\n' "$?" > "/tmp/ee-step0/$name.exit"
date -u +%FT%TZ > "/tmp/ee-step0/$name.end"
