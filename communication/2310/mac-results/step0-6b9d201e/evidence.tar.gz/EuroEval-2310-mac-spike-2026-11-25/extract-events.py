"""Extract useful evidence while preserving complete raw logs beside it."""
from pathlib import Path
import re

root=Path('/tmp/ee-step0')
pattern=re.compile(r'Started EuroEval|Completed \d+ benchmarks|Loading (the )?model|Model loaded|Metal memory:|MLX device|memory breakdown:|KV cache:|Using logprobs|Using structured generation|Not using structured|word edit distance|is a reasoning model|Contamination canary|shutdown complete|^Finished benchmarking|^Zero-shot benchmarking|^Few-shot benchmarking|^- |^Traceback|^  File |Error:|Exception:|Aborted!|[\d.]+ real\s+')
for path in root.glob('*.log'):
    if path.name=='s3-mem.log':
        continue
    text=re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '',path.read_text(errors='replace')).replace('\r','\n')
    output=[line for line in text.splitlines() if pattern.search(line)]
    path.with_suffix('.events.txt').write_text('\n'.join(output)+'\n')
