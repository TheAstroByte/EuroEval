"""Summarise local experiment evidence without inferring missing measurements."""
import datetime as dt
import json
from pathlib import Path
import re

root = Path('/tmp/ee-step0')
snapshots = []
for block in (root/'s3-mem.log').read_text().split('=== ')[1:]:
    lines = block.splitlines()
    try:
        stamp = dt.datetime.fromisoformat(lines[0].replace('Z', '+00:00'))
    except ValueError:
        continue
    def number(pattern):
        match = re.search(pattern, block)
        return float(match[1]) if match else None
    page = number(r'page size of (\d+) bytes')
    free = number(r'Pages free:\s+(\d+)')
    inactive = number(r'Pages inactive:\s+(\d+)')
    swap = number(r'vm.swapusage:.*?used = ([\d.]+)M')
    pressure_match = re.search(r'^([124])$', block, re.M)
    processes = []
    for line in lines:
        match = re.match(r'^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.+)$', line)
        if match:
            command = match[4]
            if command.startswith('VLLM::EngineCore') or re.match(r'\S*/EuroEval/\.venv/bin/python \S*/EuroEval/\.venv/bin/euroeval ', command):
                processes.append({'pid':int(match[1]), 'rss_mib':int(match[3])/1024})
    if None not in (page, free, inactive, swap) and pressure_match:
        snapshots.append({'time':stamp, 'available_gib':(free+inactive)*page/2**30, 'swap_mib':swap, 'pressure':int(pressure_match[1]), 'rss_mib':sum(p['rss_mib'] for p in processes), 'processes':processes})

footprints = {}
for path in root.glob('footprint-*.txt'):
    match = re.search(r'(\d{8}T\d{6}Z)-(\d+)\.txt$',path.name)
    if not match:
        continue
    stamp = dt.datetime.strptime(match[1], '%Y%m%dT%H%M%SZ').replace(tzinfo=dt.timezone.utc)
    value = re.search(r'Footprint:\s+([\d.]+)\s*(GB|MB|KB|B|bytes)?\s*\(',path.read_text())
    if value:
        factors={'GB':1024,'MB':1,'KB':1/1024,'B':1/2**20,'bytes':1/2**20,None:1/2**20}
        footprints.setdefault(stamp,{})[int(match[2])]=float(value[1])*factors[value[2]]

runs={}
for path in sorted(root.glob('*.log')):
    name=path.stem
    if name in ('s3-mem', 's1-install', 's1-install-retry'):
        continue
    raw=path.read_text(errors='replace')
    clean=re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', raw).replace('\r','\n')
    start_path=root/f'{name}.start'
    end_path=root/f'{name}.end'
    if start_path.exists():
        start=dt.datetime.fromisoformat(start_path.read_text().strip().replace('Z','+00:00'))
    else:
        # Explicit session timestamps recorded from process state and logs.
        start={'s2-A-sst5':'2026-11-25T07:47:28+00:00','s3-sweep-0.3':'2026-11-25T07:54:49+00:00'}.get(name)
        start=dt.datetime.fromisoformat(start) if start else None
    end=dt.datetime.fromisoformat(end_path.read_text().strip().replace('Z','+00:00')) if end_path.exists() else dt.datetime.fromtimestamp(path.stat().st_mtime,dt.timezone.utc)
    samples=[s for s in snapshots if start and start<=s['time']<=end]
    foots=[(t,values) for t,values in footprints.items() if start and start<=t<=end]
    time_match=re.search(r'([\d.]+) real\s+([\d.]+) user\s+([\d.]+) sys',clean)
    entry={'start':str(start), 'end':str(end),'exit':(root/f'{name}.exit').read_text().strip() if (root/f'{name}.exit').exists() else None,'time_s':float(time_match[1]) if time_match else None,'allocations':re.findall(r'^.*(?:memory breakdown:|KV cache:).*$',clean,re.M),'scores':re.findall(r'^- .+$',clean,re.M),'logprobs_requested':'Using logprobs as evaluation strategy' in clean,'structured_requested':'Using structured generation' in clean,'fallback':'word edit distance' in clean,'reasoning_disabled_gap':'is a reasoning model' in clean,'canary_lines':re.findall(r'^.*Contamination canary.*$',clean,re.M),'errors':re.findall(r'^.*(?:Error:|Exception:).+$',clean,re.M)[-8:]}
    entry["reported_num_failed_instances_by_shot"] = [float(value) for value in re.findall(r"'num_failed_instances': ([0-9.]+)", clean)]
    entry["completed_benchmarks"] = re.findall(r"Completed (\d+) benchmarks", clean)
    if samples:
        entry['memory']={'samples':len(samples),'peak_aggregate_rss_mib':max(s['rss_mib'] for s in samples),'min_available_gib':min(s['available_gib'] for s in samples),'peak_pressure':max(s['pressure'] for s in samples),'swap_start_mib':samples[0]['swap_mib'],'swap_end_mib':samples[-1]['swap_mib'],'swap_delta_mib':samples[-1]['swap_mib']-samples[0]['swap_mib'],'swap_peak_increase_mib':max(s['swap_mib'] for s in samples)-samples[0]['swap_mib']}
    if foots:
        t,values=max(foots,key=lambda pair:sum(pair[1].values()))
        entry['peak_sampled_aggregate_footprint_mib']=sum(values.values())
        entry['peak_footprint_time']=str(t)
        entry['peak_footprint_pids']=values
    runs[name]=entry
(root/'summary.json').write_text(json.dumps(runs,indent=2)+'\n')
for name,run in runs.items():
    print(name, 'exit',run['exit'], 'time',run['time_s'], 'fallback',run['fallback'], 'scores',run['scores'], 'errors',run['errors'][-2:])
    if name.startswith('s3') or name=='s2-A-sst5':
        print(' ',run.get('memory'), 'footprint',run.get('peak_sampled_aggregate_footprint_mib'))
