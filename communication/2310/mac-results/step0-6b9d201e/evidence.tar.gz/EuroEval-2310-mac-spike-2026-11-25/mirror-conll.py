"""Retain the last completed cache snapshot before the next forced model run."""
from pathlib import Path
import shutil
import time
source=Path('/Users/daniel/Developer/EuroEval/.euroeval_cache/model_cache/Qwen--Qwen3-0.6B/conll-en-model-outputs.json')
end=Path('/tmp/ee-step0/s2-capped-A-conll-en.exit')
target=Path('/tmp/ee-step0/conll-model-outputs.json')
while not end.exists():
    if source.exists():
        shutil.copyfile(source,target)
    time.sleep(2)
if source.exists():
    shutil.copyfile(source,target)
print('Saved CoNLL raw outputs')
