"""Check switching at the verified budget and capture the post-A footprint gap."""
import datetime as dt
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

root=Path('/tmp/ee-step0')
inputs=json.loads((root/'s3-corrected-headroom-1-inputs.json').read_text())
name='s4-verified-two-models'
command=['/usr/bin/time','-l','/tmp/ee-step0/ee','--model','Qwen/Qwen3-0.6B#no-thinking','--model','HuggingFaceTB/SmolLM2-360M-Instruct','--dataset','sst5','--gpu-memory-utilization',str(inputs['planned_cli_util']),'--num-iterations','1']
env=dict(os.environ,VLLM_METAL_MEMORY_FRACTION=str(inputs['corrected_metal_fraction']))
result={'command':command,'inputs':inputs}
(root/f'{name}.start').write_text(dt.datetime.now(dt.timezone.utc).isoformat())
with (root/f'{name}.log').open('w') as output:
    process=subprocess.Popen(command,cwd='/Users/daniel/Developer/EuroEval',env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
    deadline=time.monotonic()+300
    gap=False
    critical=0
    while process.poll() is None and time.monotonic()<deadline:
        text=(root/f'{name}.log').read_text(errors='replace')
        if not gap and 'Metal worker shutdown complete' in text:
            gap=True
            before=dt.datetime.now(dt.timezone.utc).isoformat()
            rows=subprocess.check_output(['ps','-Ao','pid=,ppid=,command='],text=True)
            pids=[]
            for line in rows.splitlines():
                match=re.match(r'\s*(\d+)\s+(\d+)\s+(.+)',line)
                if match and re.match(r'\S*/EuroEval/\.venv/bin/python \S*/EuroEval/\.venv/bin/euroeval .*--model Qwen/Qwen3-0.6B#no-thinking --model HuggingFaceTB/SmolLM2-360M-Instruct',match[3]):
                    pids.append(int(match[1]))
            captures=[]
            for pid in pids:
                snapshot=subprocess.run(['footprint','-f','bytes','-p',str(pid)],capture_output=True,text=True,timeout=5)
                path=root/f'{name}-gap-{pid}.txt'; path.write_text(snapshot.stdout+snapshot.stderr)
                captures.append({'pid':pid,'file':path.name,'exit':snapshot.returncode})
            after_text=(root/f'{name}.log').read_text(errors='replace')
            result['gap_capture']={'start':before,'end':dt.datetime.now(dt.timezone.utc).isoformat(),'b_load_announced_before_capture':'Loading the model HuggingFaceTB/SmolLM2-360M-Instruct' in text,'b_load_announced_by_capture_end':'Loading the model HuggingFaceTB/SmolLM2-360M-Instruct' in after_text,'captures':captures}
        pressure=int(subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True))
        critical=critical+1 if pressure==4 else 0
        if critical>=2:
            result['stopped']='critical pressure in two samples'; os.killpg(process.pid,signal.SIGINT); break
        time.sleep(.5)
    if process.poll() is None and time.monotonic()>=deadline:
        result['stopped']='300 second limit'; os.killpg(process.pid,signal.SIGINT)
    try:
        result['exit']=process.wait(timeout=30)
    except subprocess.TimeoutExpired:
        result['cleanup']='SIGTERM after cleanup timeout'; os.killpg(process.pid,signal.SIGTERM); result['exit']=process.wait(timeout=15)
(root/f'{name}.end').write_text(dt.datetime.now(dt.timezone.utc).isoformat())
(root/f'{name}.exit').write_text(str(result['exit'])+'\n')
(root/f'{name}-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
