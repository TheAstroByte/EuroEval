#!/bin/bash
while true; do
  stamp=$(date -u +%Y%m%dT%H%M%SZ)
  ps -Ao pid=,command= | awk '$2 == "VLLM::EngineCore" || ($2 ~ /EuroEval\/.venv\/bin\/python/ && $3 ~ /EuroEval\/.venv\/bin\/euroeval/) {print $1}' | while read -r pid; do
    footprint -f bytes -p "$pid" > "/tmp/ee-step0/footprint-${stamp}-${pid}.txt" 2>&1
  done
  sleep 15
done
