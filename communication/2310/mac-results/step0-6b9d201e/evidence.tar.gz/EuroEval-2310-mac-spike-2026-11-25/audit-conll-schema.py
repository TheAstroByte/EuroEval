"""Audit preserved unique completions against the exact requested JSON schema."""
import json
from pathlib import Path
import re
from jsonschema import Draft202012Validator

root=Path('/tmp/ee-step0')
log=(root/'s2-capped-A-conll-en.log').read_text()
schema=json.loads(re.search(r'Using structured generation with the JSON schema: (.*)',log)[1])
validator=Draft202012Validator(schema=schema)
cache=json.loads((root/'conll-model-outputs.json').read_text())
counts={'unique_completions':len(cache),'invalid_json':0,'valid_json_schema_violation':0,'schema_valid':0}
examples=[]
for key,row in cache.items():
    try:
        value=json.loads(row['sequence'])
    except json.JSONDecodeError:
        counts['invalid_json']+=1
        continue
    errors=list(validator.iter_errors(instance=value))
    if errors:
        counts['valid_json_schema_violation']+=1
        if len(examples)<5:
            examples.append({'cache_key':key,'sequence':row['sequence'],'errors':[error.message for error in errors]})
    else:
        counts['schema_valid']+=1
output={'schema':schema,'counts':counts,'schema_violation_examples':examples,'note':'Strict JSON decoding followed by the exact logged JSON schema. Unique cached completions, not bootstrap sample totals.'}
(root/'conll-schema-audit.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(counts))
