"""Summarise sampled physical footprints on each side of the model switch."""
import contextlib
import datetime as dt
import io
import json
from pathlib import Path
import re
import runpy
import sys
from zoneinfo import ZoneInfo

root=Path('/tmp/ee-step0')
with contextlib.redirect_stdout(io.StringIO()):
    data=runpy.run_path(str(root/'summarise.py'))
name=sys.argv[1] if len(sys.argv)>1 else 's4-two-models'
row=data['runs'][name]
start=dt.datetime.fromisoformat(row['start'])
end=dt.datetime.fromisoformat(row['end'])
text=(root/f'{name}.log').read_text()
match=re.search(r'\[DEBUG\] ([\d-]+ [\d:]+).*Detected generative type.*HuggingFaceTB/SmolLM2-360M-Instruct',text)
b_start=dt.datetime.strptime(match[1],'%Y-%m-%d %H:%M:%S').replace(tzinfo=ZoneInfo('Europe/Copenhagen')).astimezone(dt.timezone.utc)
result={'gap':'unobserved before B load announcement','b_load_announcement':str(b_start)}
if name=='s4-verified-two-models':
    gap=json.loads((root/'s4-verified-gap-observer.json').read_text())
    total_bytes=0
    for entry in gap['captures']:
        match=re.search(r'Footprint:\s+(\d+) B', (root/entry['file']).read_text())
        if match:
            total_bytes+=int(match[1])
    result['gap']={'aggregate_footprint_mib':total_bytes/2**20,'capture':gap,'note':'Immediate teardown sample. Model A engine was still present, before B load announcement.'}
for label,low,high in [('A',start,b_start),('B',b_start,end)]:
    samples=[(stamp,pids) for stamp,pids in data['footprints'].items() if low<=stamp<high]
    stamp,pids=max(samples,key=lambda pair:sum(pair[1].values()))
    result[label]={'peak_sampled_aggregate_footprint_mib':sum(pids.values()),'timestamp':str(stamp),'per_pid_mib':pids}
(root/f'{name}-footprints.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
