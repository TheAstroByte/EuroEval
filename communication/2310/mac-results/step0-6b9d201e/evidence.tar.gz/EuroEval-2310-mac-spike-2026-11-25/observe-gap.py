"""Capture all evaluation processes immediately after the first model shuts down."""
import datetime as dt
import json
from pathlib import Path
import re
import subprocess
import time

root=Path('/tmp/ee-step0'); log=root/'s4-verified-two-models.log'
deadline=time.monotonic()+160
while time.monotonic()<deadline:
    text=log.read_text(errors='replace')
    if 'Metal worker shutdown complete' in text:
        break
    time.sleep(.2)
else:
    raise SystemExit('No shutdown event within observer limit')
result={'start':dt.datetime.now(dt.timezone.utc).isoformat(),'b_load_announced_before':'Loading the model HuggingFaceTB/SmolLM2-360M-Instruct' in text}
rows=subprocess.check_output(['ps','-Ao','pid=,ppid=,rss=,command='],text=True)
(root/'s4-verified-gap-processes.txt').write_text(rows)
parsed=[match for line in rows.splitlines() if (match:=re.match(r'\s*(\d+)\s+(\d+)\s+(\d+)\s+(.+)',line))]
parents={int(match[1]) for match in parsed if re.match(r'\S*/EuroEval/\.venv/bin/python \S*/EuroEval/\.venv/bin/euroeval .*--model Qwen/Qwen3-0.6B#no-thinking --model HuggingFaceTB/SmolLM2-360M-Instruct',match[4])}
pids=parents|{int(match[1]) for match in parsed if match[4].startswith('VLLM::EngineCore') and int(match[2]) in parents}
result['evaluation_pids']=sorted(pids); result['captures']=[]
for pid in sorted(pids):
    capture=subprocess.run(['footprint','-f','bytes','-p',str(pid)],capture_output=True,text=True,timeout=5)
    filename=f's4-verified-gap-all-{pid}.txt'; (root/filename).write_text(capture.stdout+capture.stderr)
    result['captures'].append({'pid':pid,'file':filename,'exit':capture.returncode})
result['end']=dt.datetime.now(dt.timezone.utc).isoformat(); result['b_load_announced_after']='Loading the model HuggingFaceTB/SmolLM2-360M-Instruct' in log.read_text(errors='replace')
(root/'s4-verified-gap-observer.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2))
