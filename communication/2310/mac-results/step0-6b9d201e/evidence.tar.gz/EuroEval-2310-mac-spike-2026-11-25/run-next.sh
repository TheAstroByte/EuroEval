#!/bin/bash
cd /Users/daniel/Developer/EuroEval || exit 1
export VLLM_METAL_MEMORY_FRACTION=0.15
run() {
  local name=$1
  shift
  date -u +%FT%TZ > "/tmp/ee-step0/$name.start"
  printf '%q ' "$@" > "/tmp/ee-step0/$name.command"
  /usr/bin/time -l "$@" > "/tmp/ee-step0/$name.log" 2>&1
  local status=$?
  printf '%s\n' "$status" > "/tmp/ee-step0/$name.exit"
  date -u +%FT%TZ > "/tmp/ee-step0/$name.end"
  echo "$name exit=$status"
}
for u in 0.5 0.8; do
  run "s3-sweep-$u" /tmp/ee-step0/ee --model 'Qwen/Qwen3-0.6B#no-thinking' --dataset sst5 --gpu-memory-utilization "$u" --num-iterations 1
done
for d in sst5 hellaswag conll-en squad cnn-dailymail; do
  run "s2-capped-A-$d" /tmp/ee-step0/ee --model 'Qwen/Qwen3-0.6B#no-thinking' --dataset "$d" --gpu-memory-utilization 0.8
done
run s2-capped-A-canary /tmp/ee-step0/ee --model 'Qwen/Qwen3-0.6B#no-thinking' --task contamination-detection --language en --gpu-memory-utilization 0.8
run s4-two-models /tmp/ee-step0/ee --model 'Qwen/Qwen3-0.6B#no-thinking' --model HuggingFaceTB/SmolLM2-360M-Instruct --dataset sst5 --gpu-memory-utilization 0.8 --num-iterations 1
run s5-unsupported /tmp/ee-step0/ee --model state-spaces/mamba-130m-hf --dataset sst5 --gpu-memory-utilization 0.8 --num-iterations 1
