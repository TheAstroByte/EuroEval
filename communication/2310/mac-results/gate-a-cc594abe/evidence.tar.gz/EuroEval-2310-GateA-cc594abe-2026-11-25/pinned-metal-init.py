# SPDX-License-Identifier: Apache-2.0
"""Native paged-attention Metal kernels dispatched through MLX.

Usage::

    from vllm_metal.metal import get_ops
    ops = get_ops()
    out = ops.paged_attention_primitive(query, key_cache, value_cache, ...)
"""

from __future__ import annotations

import functools
import importlib
import importlib.util
import logging
import platform
import re
from pathlib import Path
from types import ModuleType

from vllm_metal.metal.constants import PA_WINDOW_ROWS, PARTITION_SIZE

logger = logging.getLogger(__name__)

_THIS_DIR = Path(__file__).resolve().parent
_KERNELS_V2_DIR = _THIS_DIR / "kernels_v2"

# Cached after first get_ops() call.  By default both the .cpp extension and
# the required Metal shader libraries are loaded prebuilt from the package,
# so there is no first-request shader compile. Set VLLM_METAL_BUILD_FROM_SOURCE=1
# to recompile the .so from source
# AND compile the shaders in-process from .metal (for kernel developers
# iterating on paged_ops.cpp or the .metal sources); editing .metal then
# requires restarting the interpreter to pick up changes.  Either way the
# libraries are held in MLX's cache for the lifetime of the process.
_ops_module: ModuleType | None = None


@functools.cache
def _read_metal_source(path: Path) -> str:
    """Read a .metal file and strip local #include directives.

    Cached for the process lifetime: the library source builders pull
    in shared shaders (e.g. utils.metal), so without this each staleness check
    or source-mode init would re-read and re-strip the same files several times.
    """
    text = path.read_text()
    # Remove #include "..." for our vendored files (keep <metal_stdlib> etc.)
    text = re.sub(r'#include\s+"[^"]*"', "", text)
    return text


def _read_v2_metal_source(filename: str) -> str:
    """Read a kernels_v2 .metal source file."""
    return _read_metal_source(_KERNELS_V2_DIR / filename)


def _build_v2_paged_attention_source() -> str:
    """Concatenate float8 + utils + turboquant + v2 paged_attention (online softmax)."""
    parts = [
        f"#define VLLM_METAL_PARTITION_SIZE {PARTITION_SIZE}",
        f"#define VLLM_METAL_PA_WINDOW_ROWS {PA_WINDOW_ROWS}",
        _read_metal_source(_KERNELS_V2_DIR / "float8.metal"),
        _read_metal_source(_KERNELS_V2_DIR / "utils.metal"),
        _read_metal_source(_KERNELS_V2_DIR / "turboquant.metal"),
        _read_metal_source(_KERNELS_V2_DIR / "reshape_and_cache.metal"),
        _read_metal_source(_KERNELS_V2_DIR / "pagedattention.metal"),
        _read_metal_source(_KERNELS_V2_DIR / "pagedattention_tiled.metal"),
    ]
    return "\n".join(parts)


def _build_gdn_source() -> str:
    """GDN linear attention kernel source."""
    parts = [
        _read_metal_source(_KERNELS_V2_DIR / "utils.metal"),
        _read_metal_source(_KERNELS_V2_DIR / "gdn_linear_attention.metal"),
        _read_metal_source(_KERNELS_V2_DIR / "gdn_state_scatter.metal"),
    ]
    return "\n".join(parts)


def _build_mla_paged_attention_source() -> str:
    """Concatenate utils + mla into a single source for the MLA library."""
    parts = [
        _read_metal_source(_KERNELS_V2_DIR / "utils.metal"),
        _read_metal_source(_KERNELS_V2_DIR / "mla.metal"),
    ]
    return "\n".join(parts)


def _build_nax_source() -> str:
    """Read the self-contained NAX prefill attention source."""
    return _read_metal_source(_KERNELS_V2_DIR / "pagedattention_nax.metal")


def _try_init_nax_library(
    mod: ModuleType,
    *,
    disabled: bool,
    build_from_source: bool,
    prebuilt_path: Path | None = None,
) -> bool:
    """Load optional NAX support, returning False when unavailable."""
    if disabled:
        logger.info("NAX prefill attention disabled by VLLM_METAL_DISABLE_NAX")
        return False

    try:
        if not mod.nax_supported():
            return False
        if build_from_source:
            mod.init_nax_library(_build_nax_source())
        else:
            if prebuilt_path is None or not prebuilt_path.exists():
                logger.warning(
                    "NAX prefill attention is supported on this machine, but "
                    "the prebuilt library is missing at %s; using the non-NAX "
                    "fallback",
                    prebuilt_path or "<unknown path>",
                )
                return False
            mod.init_nax_library_path(str(prebuilt_path))
        return True
    except (OSError, RuntimeError) as exc:
        logger.warning(
            "NAX prefill attention initialization failed; using the "
            "non-NAX fallback: %s",
            exc,
        )
        return False


def metal_mla_paged_attention(
    q_nope,  # [total_q_tokens, num_heads, kv_lora_rank]
    q_pe,  # [total_q_tokens, num_heads, qk_rope_head_dim]
    latent_cache,  # [num_blocks, block_size, kv_lora_rank + qk_rope_head_dim]
    block_tables,  # [num_seqs, max_blocks_per_seq], int32
    context_lens,  # [num_seqs], uint32
    cu_seqlens_q,  # [num_seqs + 1], int32
    scale: float,
    heads_per_tg: int = 1,
):
    """Paged Multi-head Latent Attention (RFC #360). Returns a lazy
    ``mx.array`` whose evaluation triggers the kernel dispatch.

    Q is expected to be already projected through ``embed_q`` (so
    q_nope is in kv_lora_rank space) and ``q_pe`` is RoPE-applied. The
    caller is responsible for ``unembed_out`` on the result to recover
    v_head_dim.

    The dispatch is wrapped in an MLX Primitive so it participates in
    MLX's lazy graph — no ``mx.eval`` / ``mx.synchronize`` boundary
    inside this entry. ``heads_per_tg`` (G) controls cross-head KV
    amortization: each threadgroup processes G consecutive query
    heads sharing the same latent KV; ``num_heads`` must be divisible
    by G. Currently instantiated for G ∈ {1, 2}.
    """
    import mlx.core as mx

    if q_nope.shape[2] != latent_cache.shape[2] - q_pe.shape[2]:
        raise ValueError(
            f"MLA shape mismatch: q_nope.shape[2]={q_nope.shape[2]} must equal "
            f"latent_cache.shape[2] ({latent_cache.shape[2]}) - "
            f"q_pe.shape[2] ({q_pe.shape[2]})"
        )

    block_size = latent_cache.shape[1]

    total_q_tokens = int(q_nope.shape[0])
    num_heads = int(q_nope.shape[1])
    kv_lora_rank = int(q_nope.shape[2])
    # ``mx.zeros`` here is lazy — the C++ side replaces ``out``'s
    # descriptor with the Primitive output before the zeros ever
    # evaluate, so the memset is never scheduled.
    out = mx.zeros((total_q_tokens, num_heads, kv_lora_rank), dtype=q_nope.dtype)

    ops = get_ops()
    ops.mla_paged_attention_primitive(
        q_nope,
        q_pe,
        latent_cache,
        block_tables,
        context_lens,
        cu_seqlens_q,
        block_size,
        scale,
        heads_per_tg,
        out,
    )
    return out


def get_ops() -> ModuleType:
    """Import the native paged_ops extension and initialise its Metal libraries.

    By default the prebuilt ``.so`` and required ``.metallib`` libraries are
    loaded by path via MLX
    (``Device::get_library(name, path)``). When ``VLLM_METAL_BUILD_FROM_SOURCE``
    is set, the ``.so`` is rebuilt and the shader sources are read, pre-processed
    (includes inlined) and JIT-compiled in-process via
    ``mlx::core::metal::Device::get_library(name, builder)`` instead.

    Returns:
        The ``_paged_ops`` module with ``paged_attention_primitive()`` and
        the TurboQuant / GDN / MLA ops.
    """
    global _ops_module
    if _ops_module is not None:
        return _ops_module

    # The prebuilt .so links `-lmlx` with no rpath, so it records a dependency on
    # `@rpath/libmlx.dylib` (libmlx's install name) that it cannot resolve on its
    # own; dyld instead satisfies it against an already-resident libmlx, matched
    # by install name (`-undefined dynamic_lookup` resolves any stragglers the
    # same way; see build.py). Both need libmlx loaded first, so import mlx.core
    # now to make it resident before the .so is dlopen'd below.
    import mlx.core  # noqa: F401

    # 1. Locate the native extension: load the prebuilt artifact by default;
    #    only compile from source when explicitly opted in (no silent fallback).
    from vllm_metal import envs
    from vllm_metal.metal.build import build, output_path, stale_artifacts

    build_from_source = envs.VLLM_METAL_BUILD_FROM_SOURCE
    if build_from_source:
        so_path = build()
    else:
        so_path = output_path()
        if not so_path.exists():
            raise RuntimeError(
                f"Prebuilt native extension not found at {so_path}. Install a "
                f"vllm-metal release wheel (which ships it prebuilt), or set "
                f"VLLM_METAL_BUILD_FROM_SOURCE=1 to compile it from source "
                f"(requires Xcode command-line tools)."
            )
        # Locally-built artifacts (the .so and the .metallib shaders) drift if a
        # developer edits paged_ops.cpp or a .metal file without rebuilding. Fail
        # loudly rather than run stale kernels — but do NOT auto-build, which
        # would reintroduce the silent compile this design removed. No-op for
        # wheel installs (no stamps), so end users are never affected.
        stale = stale_artifacts()
        if stale:
            raise RuntimeError(
                f"Prebuilt Metal artifacts are stale vs the current sources "
                f"({', '.join(p.name for p in stale)}): a kernel source was "
                f"edited without rebuilding. Set VLLM_METAL_BUILD_FROM_SOURCE=1 "
                f"to build from source, or run `python -m vllm_metal.metal.build` "
                f"to refresh the prebuilt artifacts."
            )

    # 2. Import the built extension
    spec = importlib.util.spec_from_file_location("_paged_ops", str(so_path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load extension from {so_path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    # 3. Initialise the required Metal shader libraries (v2 online-softmax, GDN
    #    linear attention, MLA paged attention).  By default we load the
    #    precompiled .metallib files shipped in the wheel (no first-request
    #    shader compile); only compile the shaders in-process when the developer
    #    opts in via VLLM_METAL_BUILD_FROM_SOURCE (no silent fallback).
    # NAX is optional: unsupported hardware, missing artifacts, and load
    # failures retain the established dispatch path.
    nax_prebuilt_path: Path | None = None
    if build_from_source:
        mod.init_v2_library(_build_v2_paged_attention_source())
        mod.init_gdn_library(_build_gdn_source())
        mod.init_mla_library(_build_mla_paged_attention_source())
    else:
        from vllm_metal.metal.build import (
            METALLIB_NAMES,
            NAX_METALLIB_NAME,
            metallib_path,
        )

        missing = [n for n in METALLIB_NAMES if not metallib_path(n).exists()]
        if missing:
            raise RuntimeError(
                f"Prebuilt Metal libraries missing: {missing} (expected in "
                f"{_THIS_DIR}). Install a vllm-metal release wheel, or set "
                f"VLLM_METAL_BUILD_FROM_SOURCE=1 to compile shaders from source."
            )
        for name in METALLIB_NAMES:
            mod.init_library_path(name, str(metallib_path(name)))
        nax_prebuilt_path = metallib_path(NAX_METALLIB_NAME)

    nax_ready = _try_init_nax_library(
        mod,
        disabled=envs.VLLM_METAL_DISABLE_NAX,
        build_from_source=build_from_source,
        prebuilt_path=nax_prebuilt_path,
    )
    if nax_ready:
        logger.info("NAX prefill attention kernels loaded (M5 tensor units)")

    _ops_module = mod
    logger.info("Native paged-attention Metal kernels loaded")
    return mod


def warm_up_kernels() -> None:
    """Front-load v2 / GDN / MLA Metal library loading at startup.

    :func:`get_ops` imports the C++ ``_paged_ops`` extension and initialises the
    v2 / GDN / MLA Metal libraries — by default loading the precompiled
    ``.metallib`` files, or (under ``VLLM_METAL_BUILD_FROM_SOURCE``) compiling
    the shader source synchronously inside each ``init_*_library`` call. Calling
    it here moves that cost off the first request and fails fast at startup if
    the libraries are missing or the shaders cannot compile on this macOS (e.g.
    an unsupported Metal language version).

    The load/compile is process-wide with no per-cache state, which is why this
    takes no arguments.
    """
    macos_version = platform.mac_ver()[0]
    logger.info("Warming up v2 paged-attention Metal kernels...")
    try:
        get_ops()
    except Exception as e:
        raise RuntimeError(
            f"Failed to compile paged-attention Metal kernels on "
            f"macOS {macos_version}: {e}"
        ) from e
    logger.info("Paged-attention Metal kernel warm-up complete")
