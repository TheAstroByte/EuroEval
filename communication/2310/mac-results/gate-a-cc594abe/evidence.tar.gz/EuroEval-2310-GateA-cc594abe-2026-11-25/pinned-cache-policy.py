# SPDX-License-Identifier: Apache-2.0
"""Cache-policy ownership for the v1 Metal runtime."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

import mlx.core as mx
import torch
from vllm.logger import init_logger
from vllm.utils.math_utils import cdiv
from vllm.v1.kv_cache_interface import (
    FullAttentionSpec,
    KVCacheConfig,
    KVCacheSpec,
    MambaSpec,
    MLAAttentionSpec,
    SlidingWindowSpec,
)

from vllm_metal.attention.caches.turboquant import (
    BLOCK_SIZE as TQ_BLOCK_SIZE,
)
from vllm_metal.attention.caches.turboquant import (
    QUANT_PARAMS,
    V_QUANT_PARAMS,
    packed_dim,
)
from vllm_metal.attention.runtime.hybrid import HybridPagedAttentionRuntime
from vllm_metal.attention.runtime.hybrid_plan import HybridRuntimePlan
from vllm_metal.attention.runtime.mla import MLAPagedAttentionRuntime
from vllm_metal.attention.runtime.protocol import PagedAttentionRuntime
from vllm_metal.attention.runtime.sdpa import SDPAPagedAttentionRuntime
from vllm_metal.attention.yoco import try_enable_gemma4_yoco_fast_prefill
from vllm_metal.config import (
    PAGED_ATTENTION_MIN_BLOCKS,
    MetalConfig,
    get_config,
)
from vllm_metal.pytorch_backend.tensor_bridge import MLX_TO_TORCH_DTYPE
from vllm_metal.stt.policy import STT_SCHED_AVAILABLE_BYTES
from vllm_metal.v1.gemma4_mtp import Gemma4MTPTargetMetadata
from vllm_metal.v1.model_adapter import ModelAdapter

if TYPE_CHECKING:
    from vllm_metal.v1.model_runner import MetalModelRunner
    from vllm_metal.v1.worker import MetalWorker

logger = init_logger(__name__)


@dataclass(frozen=True, kw_only=True)
class TurboQuantAttentionSpec(FullAttentionSpec):
    """FullAttentionSpec for TurboQuant-compressed KV cache.

    Publishes the packed per-(head, token) byte count through the base
    spec's ``state_content_bytes`` field so vLLM's scheduler budgets
    blocks from the true compressed page size — without lying about
    ``head_size``. Since vLLM 0.28.0 the scheduler derives ``page_size_bytes``
    from that field and ``real_page_size_bytes`` is only an alias, so
    overriding the latter would not reach it; publishing the field is the
    same mechanism upstream's ``TurboQuantAttentionBackend.customize_spec``
    uses for its packed layout.
    """

    k_quant: str
    v_quant: str

    def __post_init__(self) -> None:
        # Derive the packed per-cell size here, not in the builder, so a
        # bare construction can never fall back to the dense int8 formula
        # (the same in-class derivation pattern as the base head_size_v).
        super().__post_init__()
        if self.state_content_bytes is None:
            object.__setattr__(
                self,
                "state_content_bytes",
                turboquant_state_content_bytes(
                    self.head_size, self.k_quant, self.v_quant
                ),
            )

    @classmethod
    def merge(cls, specs: Sequence[FullAttentionSpec]) -> TurboQuantAttentionSpec:
        # vLLM's uniformity probe treats AssertionError as "mixed spec type".
        turbo_specs: list[TurboQuantAttentionSpec] = []
        for spec in specs:
            if not isinstance(spec, TurboQuantAttentionSpec):
                raise AssertionError(
                    "All attention layers in the same KV cache group must be "
                    "TurboQuantAttentionSpec."
                )
            turbo_specs.append(spec)
        if not turbo_specs:
            raise ValueError("TurboQuantAttentionSpec.merge() requires specs")

        k_set = {s.k_quant for s in turbo_specs}
        v_set = {s.v_quant for s in turbo_specs}
        if len(k_set) != 1 or len(v_set) != 1:
            raise ValueError(
                "All TurboQuant layers in the same cache group must share the "
                "same (k_quant, v_quant); mixed-quant groups are not supported."
            )
        first = turbo_specs[0]
        return cls(
            block_size=first.block_size,
            num_kv_heads=first.num_kv_heads,
            head_size=first.head_size,
            head_size_v=first.head_size_v,
            dtype=first.dtype,
            page_size_padded=first.page_size_padded,
            sliding_window=cls.merge_window_sizes(
                {s.sliding_window for s in turbo_specs if s.sliding_window is not None}
            ),
            attention_chunk_size=cls.merge_window_sizes(
                {
                    s.attention_chunk_size
                    for s in turbo_specs
                    if s.attention_chunk_size is not None
                }
            ),
            k_quant=k_set.pop(),
            v_quant=v_set.pop(),
        )


def turboquant_state_content_bytes(head_dim: int, k_quant: str, v_quant: str) -> int:
    """Packed bytes for one (head, token) cell: K + V payload plus scales.

    The scale term is 3 fp16 tensors (k_scale, v_scale, v_bias) per
    ``TQ_BLOCK_SIZE``-wide group, hence ``3 * scale_groups * 2`` bytes.
    """
    k_bits = QUANT_PARAMS[k_quant]["bits"]
    v_bits = V_QUANT_PARAMS[v_quant]["bits"]
    k_packed = packed_dim(head_dim, k_bits)
    v_packed = packed_dim(head_dim, v_bits)
    scale_groups = head_dim // TQ_BLOCK_SIZE
    return k_packed + v_packed + 3 * scale_groups * 2


def turboquant_page_size_bytes(
    block_size: int, num_kv_heads: int, head_dim: int, k_quant: str, v_quant: str
) -> int:
    """Calculate TurboQuant-compressed page size for one layer."""
    return (
        block_size
        * num_kv_heads
        * turboquant_state_content_bytes(head_dim, k_quant, v_quant)
    )


def _build_turboquant_attention_spec(
    block_size: int,
    num_kv_heads: int,
    head_dim: int,
    k_quant: str,
    v_quant: str,
) -> TurboQuantAttentionSpec:
    """Build a TurboQuantAttentionSpec for a single attention layer.

    The spec derives its packed ``state_content_bytes`` itself, so the
    scheduler allocates the right number of blocks and ``head_size``
    stays equal to the model's real head_dim.
    """
    return TurboQuantAttentionSpec(
        block_size=block_size,
        num_kv_heads=num_kv_heads,
        head_size=head_dim,
        dtype=torch.int8,
        k_quant=k_quant,
        v_quant=v_quant,
    )


@dataclass(frozen=True)
class _PagedAttentionPlan:
    block_size: int
    fraction: float
    metal_limit: int
    usable_metal: int
    model_memory: int
    overhead: int
    per_block_bytes: int
    base_kv_budget: int
    kv_budget: int
    num_blocks: int

    def format_breakdown(self) -> str:
        parts = [
            f"metal_limit={self.metal_limit / 1e9:.2f}GB",
            f"fraction={self.fraction}",
            f"usable_metal={self.usable_metal / 1e9:.2f}GB",
            f"model_memory={self.model_memory / 1e9:.2f}GB",
            f"overhead={self.overhead / 1e9:.2f}GB",
        ]
        parts.append(f"kv_budget={self.kv_budget / 1e9:.2f}GB")
        return ", ".join(parts)

    def format_mitigations(self) -> str:
        mitigations = [
            f"increase --gpu-memory-utilization (currently {self.fraction})",
            "use a smaller or more quantized model",
        ]
        return "Mitigations: " + "; ".join(mitigations) + "."


class ModelCachePolicy:
    """Cache shape, size, and backend-selection policy for one runner."""

    def __init__(self, runner: MetalModelRunner, model_adapter: ModelAdapter) -> None:
        self._runner = runner
        self._model_adapter = model_adapter

    def validate_paged_attention_support(self) -> None:
        """Validate that the loaded model can run on the paged-attention path."""
        self._require_supported_per_layer_shapes()
        # ``require_uniform_kv_heads`` is the fail-fast for configs whose
        # ``num_global_key_value_heads`` differs from ``num_key_value_heads``
        # and which would silently fall back to the scalar uniform cache
        # path with wrong sizing.  Adapters that populate
        # ``kv_heads_per_layer`` via ``build_per_layer_kv_shapes`` (Gemma4
        # 26B/31B) have already opted into the heterogeneous cache and
        # handle mismatched KV counts layer-by-layer, so the uniform
        # guarantee does not apply and the check is skipped for them.
        if self._runner.kv_heads_per_layer is None:
            self._model_adapter.require_uniform_kv_heads(
                self._runner.model_args,
                self._runner.num_kv_heads,
            )

    def scheduler_memory_reporting_mode(
        self,
    ) -> Literal[
        "paged_attention_capacity",
        "paged_attention_layout_budget",
        "pooling_no_kv",
    ]:
        """Return which scheduler memory-reporting mode worker should use."""
        pooling_backend = self._runner._pooling_backend
        if (
            pooling_backend is not None
            and not pooling_backend.capabilities.uses_kv_cache
        ):
            return "pooling_no_kv"
        if self._uses_upstream_storage():
            return "paged_attention_layout_budget"
        return "paged_attention_capacity"

    def _hybrid_plan(self) -> HybridRuntimePlan:
        """Return the resolved hybrid plan, failing fast if lifecycle skipped it."""
        plan = self._runner.hybrid_runtime_plan
        if plan is None:
            raise RuntimeError(
                "hybrid model has no resolved hybrid_runtime_plan; "
                "ModelLifecycle.resolve_model_dims must run before cache sizing"
            )
        return plan

    def _uses_upstream_storage(self) -> bool:
        return self._runner.is_hybrid or (
            not self._runner.is_mla and self._runner._draft_dims is None
        )

    def _uses_grouped_attention(self) -> bool:
        """Return whether the scheduler keeps distinct attention-window groups."""
        if self._runner.is_hybrid:
            return True
        sliding_windows = self._runner.sliding_window_per_layer
        vllm_config = self._runner.vllm_config
        return (
            # Mixed attention windows need grouped allocation even when all
            # layers have the same head geometry (for example, OLMo 3).
            sliding_windows is not None
            and self._runner._yoco_cache_mapping is None
            and not self._runner.is_mla
            and not self._use_turboquant(get_config())
            and self._runner.vllm_config.speculative_config is None
            and self._runner._gemma4_mtp_assistant is None
            and not vllm_config.scheduler_config.disable_hybrid_kv_cache_manager
            and vllm_config.cache_config.num_gpu_blocks_override is None
            and any(window >= 0 for window in sliding_windows)
            and any(window < 0 for window in sliding_windows)
        )

    def get_kv_cache_spec(self) -> dict[str, KVCacheSpec]:
        """Build the scheduler-visible KV cache specification."""
        pooling_backend = self._runner._pooling_backend
        if (
            pooling_backend is not None
            and not pooling_backend.capabilities.uses_kv_cache
        ):
            return {}

        self._require_supported_per_layer_shapes()
        block_size = self._runner.cache_config.block_size
        torch_dtype = MLX_TO_TORCH_DTYPE[self._require_kv_cache_dtype()]
        config = get_config()
        use_turboquant = self._use_turboquant(config)

        kv_heads, head_dims = self._cache_layer_shapes(self._runner.num_layers)
        # Under YOCO KV sharing only the leading ``num_cache_layers`` layers own
        # a cache; the trailing ones reuse it (see ``_cache_layer_mapping``, whose
        # mapping assigns the owners first).  Emit no spec for the sharers, so
        # the engine sizes against the layers that were actually allocated --
        # the same way upstream expresses sharing by omission in
        # ``GPUModelRunner.get_kv_cache_spec``.
        num_spec_layers = self._runner.num_layers
        if self._runner._yoco_cache_mapping is not None:
            num_spec_layers, _ = self._runner._yoco_cache_mapping
        specs: dict[str, KVCacheSpec] = {}
        use_grouped_attention = self._uses_grouped_attention()

        def attention_spec(layer_idx: int) -> KVCacheSpec:
            return self._attention_layer_spec(
                layer_idx,
                block_size=block_size,
                num_kv_heads=kv_heads[layer_idx],
                head_dim=head_dims[layer_idx],
                torch_dtype=torch_dtype,
                use_turboquant=use_turboquant,
                config=config,
                use_grouped_attention=use_grouped_attention,
            )

        if self._runner.is_hybrid:
            hybrid_plan = self._hybrid_plan()
            state_spec = self._state_layer_spec(hybrid_plan)
            for layer_idx in range(num_spec_layers):
                if hybrid_plan.layers.is_state_layer(layer_idx):
                    specs[f"layers.{layer_idx}.{hybrid_plan.family.layer_name}"] = (
                        state_spec
                    )
                elif hybrid_plan.layers.is_attention_layer(layer_idx):
                    specs[f"layers.{layer_idx}.self_attn"] = attention_spec(layer_idx)
        else:
            for layer_idx in range(num_spec_layers):
                specs[f"layers.{layer_idx}.self_attn"] = attention_spec(layer_idx)

        specs.update(
            self._draft_layer_specs(block_size=block_size, torch_dtype=torch_dtype)
        )
        return specs

    def _state_layer_spec(self, hybrid_plan: HybridRuntimePlan) -> MambaSpec:
        """Build the scheduler-visible spec shared by every state layer."""
        cache_config = self._runner.cache_config
        mamba_block_size = cache_config.mamba_block_size
        # Upstream resolves this during config setup and asserts it here.
        assert mamba_block_size is not None
        return hybrid_plan.state_cache_spec(
            mamba_block_size=mamba_block_size,
            page_size_padded=cache_config.mamba_page_size_padded,
            mamba_cache_mode=cache_config.mamba_cache_mode,
        )

    def _attention_layer_spec(
        self,
        layer_idx: int,
        *,
        block_size: int,
        num_kv_heads: int,
        head_dim: int,
        torch_dtype: torch.dtype,
        use_turboquant: bool,
        config: MetalConfig,
        use_grouped_attention: bool,
    ) -> KVCacheSpec:
        """Build the scheduler-visible spec for one attention layer."""
        if use_turboquant:
            return _build_turboquant_attention_spec(
                block_size=block_size,
                num_kv_heads=num_kv_heads,
                head_dim=head_dim,
                k_quant=config.k_quant,
                v_quant=config.v_quant,
            )
        # MLA caches a single latent tensor per layer, not separate K and V
        # (see ``MLAPagedLatentCache``), which is why ``_kv_factor`` bills it
        # at 1.  ``FullAttentionSpec`` bakes the 2x K/V factor into
        # ``page_size_bytes`` (head_size + head_size_v), so describing MLA with
        # it makes the engine halve the block count it plans against relative
        # to the pool actually allocated.
        if self._runner.is_mla:
            return MLAAttentionSpec(
                block_size=block_size,
                num_kv_heads=num_kv_heads,
                head_size=head_dim,
                dtype=torch_dtype,
            )
        if use_grouped_attention:
            return self._build_attention_spec(
                layer_idx=layer_idx,
                block_size=block_size,
                num_kv_heads=num_kv_heads,
                head_dim=head_dim,
                torch_dtype=torch_dtype,
            )
        return FullAttentionSpec(
            block_size=block_size,
            num_kv_heads=num_kv_heads,
            head_size=head_dim,
            dtype=torch_dtype,
        )

    def _draft_layer_specs(
        self, *, block_size: int, torch_dtype: torch.dtype
    ) -> dict[str, KVCacheSpec]:
        """Scheduler-visible spec for the draft model's committed-KV group.

        Draft models must be plain transformers (no sliding window / MLA /
        hybrid) -- enforced at startup by ``resolve_draft_dims`` -- so a
        uniform ``FullAttentionSpec`` per layer under distinct synthetic names
        is enough to let the scheduler size the draft's KV cache.
        """
        draft_dims = self._runner._draft_dims
        if draft_dims is None:
            return {}
        return {
            f"draft_layers.{layer_idx}.self_attn": FullAttentionSpec(
                block_size=block_size,
                num_kv_heads=draft_dims.num_kv_heads,
                head_size=draft_dims.head_dim,
                dtype=torch_dtype,
            )
            for layer_idx in range(draft_dims.num_layers)
        }

    def _build_attention_spec(
        self,
        layer_idx: int,
        block_size: int,
        num_kv_heads: int,
        head_dim: int,
        torch_dtype: torch.dtype,
    ) -> FullAttentionSpec | SlidingWindowSpec:
        """Build the scheduler spec for one standard attention cache layer."""
        sliding_windows = self._runner.sliding_window_per_layer
        if sliding_windows is not None and sliding_windows[layer_idx] >= 0:
            return SlidingWindowSpec(
                block_size=block_size,
                num_kv_heads=num_kv_heads,
                head_size=head_dim,
                dtype=torch_dtype,
                sliding_window=sliding_windows[layer_idx],
            )
        return FullAttentionSpec(
            block_size=block_size,
            num_kv_heads=num_kv_heads,
            head_size=head_dim,
            dtype=torch_dtype,
        )

    def initialize_kv_cache(self, kv_cache_config: KVCacheConfig) -> None:
        """Bind layout-driven caches from the final engine configuration.

        Count-initialized speculative/MLA runtimes adopt the engine's groups;
        other runtimes bind the engine's shared backing here.
        """
        self._adopt_draft_scheduler_group(kv_cache_config)
        runtime = self._runner.paged_attention_runtime
        pooling_backend = self._runner._pooling_backend
        if (
            pooling_backend is not None
            and not pooling_backend.capabilities.uses_kv_cache
        ):
            if kv_cache_config.kv_cache_groups or kv_cache_config.kv_cache_tensors:
                raise ValueError(
                    "Metal encoder pooling does not use KV cache, but vLLM "
                    "returned a non-empty KV cache config."
                )
            logger.info("Encoder pooling: no KV cache initialized.")
            return

        if self._uses_upstream_storage():
            if runtime is not None:
                raise RuntimeError(
                    "upstream storage must be initialized after cache planning"
                )
            self._initialize_upstream_storage(kv_cache_config)
            logger.info(
                "KV cache config received: %d grouped blocks "
                "(MLX layout initialized from vLLM config)",
                kv_cache_config.num_blocks,
            )
            return

        if runtime is not None and kv_cache_config.num_blocks > runtime.num_blocks():
            raise ValueError(
                f"Engine KV cache config requests {kv_cache_config.num_blocks} "
                f"blocks but the Metal paged pool was allocated with "
                f"{runtime.num_blocks()}. vllm-metal sizes its pool from "
                "available Metal memory and cannot grow it afterwards. If "
                "--num-gpu-blocks-override is set, lower or remove it; "
                "otherwise this is a capacity-accounting bug, please report it."
            )
        if runtime is not None:
            self._adopt_scheduler_groups(runtime, kv_cache_config)
        logger.info(
            "KV cache config received: %d blocks (MLX manages cache internally)",
            kv_cache_config.num_blocks,
        )

    def _initialize_upstream_storage(self, kv_cache_config: KVCacheConfig) -> None:
        self.validate_paged_attention_support()
        if self._runner.is_hybrid:
            runtime = self._build_hybrid_backend()
            runtime.initialize_from_config(kv_cache_config)
            runtime.patch_model(self._runner.model)
            self._runner.install_paged_attention_runtime(
                runtime, block_size=self._runner.cache_config.block_size
            )
            self._runner.install_drafter(
                num_blocks=kv_cache_config.num_blocks,
                block_size=self._runner.cache_config.block_size,
            )
            return
        model_layer_names = self._attention_layer_names()
        runtime = self._build_sdpa_backend(
            block_size=self._runner.cache_config.block_size
        )
        runtime.initialize_from_config(kv_cache_config, model_layer_names)
        n_patched = runtime.patch_model(self._runner.model)
        block_size = runtime.kv_group_block_sizes()[0]
        self.install_gemma4_mtp_kv_sharing(runtime, block_size=block_size)
        self._runner.install_paged_attention_runtime(runtime, block_size=block_size)
        self._runner.install_drafter(
            num_blocks=kv_cache_config.num_blocks, block_size=block_size
        )
        try_enable_gemma4_yoco_fast_prefill(
            self._runner.model,
            self._runner.model_args,
            num_paged_layers=n_patched,
        )

    def _adopt_scheduler_groups(
        self,
        runtime: PagedAttentionRuntime,
        kv_cache_config: KVCacheConfig,
    ) -> None:
        if isinstance(runtime, SDPAPagedAttentionRuntime):
            runtime.adopt_scheduler_groups(
                kv_cache_config, self._attention_layer_names()
            )
            self._runner.install_paged_attention_runtime(
                runtime, block_size=runtime.kv_group_block_sizes()[0]
            )

    def _adopt_draft_scheduler_group(self, kv_cache_config: KVCacheConfig) -> None:
        """Tell the drafter which scheduler KV group owns its committed KV.

        The draft model's own physical backend is already built by this
        point (``install_drafter``, called from ``determine_available_memory``
        -- before the engine has computed ``kv_cache_config``, so it cannot
        know its group index at construction time). This runs after, once
        ``kv_cache_config.kv_cache_groups`` exists, and resolves which group
        the synthetic ``draft_layers.*`` names from
        ``ModelCachePolicy._draft_layer_specs`` landed in -- mirroring
        ``_adopt_scheduler_groups``'s resolution for the target. No-op without a
        draft model configured.
        """
        draft_dims = self._runner._draft_dims
        if draft_dims is None:
            return
        layer_names = tuple(
            f"draft_layers.{layer_idx}.self_attn"
            for layer_idx in range(draft_dims.num_layers)
        )
        group_indices = self._scheduler_group_indices_for_layers(
            kv_cache_config, layer_names
        )
        if len(group_indices) != 1:
            raise NotImplementedError(
                "draft-model speculative decoding requires all draft layers "
                "to share one scheduler KV cache group"
            )

        from vllm_metal.v1.draft_model_proposer import DraftModelProposer

        drafter = self._runner._drafter
        if not isinstance(drafter, DraftModelProposer):
            raise RuntimeError(
                "draft KV-cache spec registered but no DraftModelProposer is "
                f"installed (got {type(drafter).__name__})"
            )
        drafter.adopt_committed_group(group_indices[0])

    def _scheduler_group_indices_for_layers(
        self,
        kv_cache_config: KVCacheConfig,
        layer_names: tuple[str, ...],
    ) -> tuple[int, ...]:
        layer_set = set(layer_names)
        layer_to_group: dict[str, int] = {}
        for group_index, group in enumerate(kv_cache_config.kv_cache_groups):
            for layer_name in group.layer_names:
                if layer_name in layer_set:
                    layer_to_group[layer_name] = group_index

        missing = layer_set - set(layer_to_group)
        if missing:
            raise ValueError(
                "KV cache config is missing scheduler groups for layers: "
                f"{', '.join(sorted(missing))}"
            )
        return tuple(dict.fromkeys(layer_to_group[name] for name in layer_names))

    def _attention_layer_names(self) -> tuple[str, ...]:
        num_layers, _ = self._cache_layer_mapping()
        return tuple(f"layers.{layer_idx}.self_attn" for layer_idx in range(num_layers))

    def get_cache_block_size_bytes(self) -> int:
        """Return the byte size of one cache block.

        For per-layer shapes, sums each layer's contribution individually.
        For uniform shapes, reduces to the existing product formula. Adds the
        draft model's own per-block bytes when one is configured (see
        ``_draft_cache_block_size_bytes``), so every caller of this method --
        scheduler capacity reporting and the local budget-to-num_blocks
        division alike -- sizes against the true combined cost of one block
        index, which now has real storage in both the target's and the
        draft's KV-cache groups.
        """
        self._require_supported_per_layer_shapes()
        block_size = self._runner.cache_config.block_size
        dtype_size = self._require_kv_cache_dtype().size
        num_kv_layers = self._num_kv_cache_layers()

        # TurboQuant uses quantized KV cache with different byte layout
        config = get_config()
        if self._use_turboquant(config):
            return (
                num_kv_layers
                * turboquant_page_size_bytes(
                    block_size=block_size,
                    num_kv_heads=self._runner.num_kv_heads,
                    head_dim=self._runner.head_dim,
                    k_quant=config.k_quant,
                    v_quant=config.v_quant,
                )
                + self._draft_cache_block_size_bytes()
            )

        return (
            self._kv_factor() * block_size * dtype_size * self._kv_layer_size_sum()
            + self._draft_cache_block_size_bytes()
        )

    def draft_scratch_reserve_blocks(self) -> int:
        """Blocks reserved for the draft model's speculative lookahead tail.

        The committed portion of the draft's KV is a normal scheduler-owned
        group (see ``_draft_layer_specs``), so the scheduler owns every block
        id in ``[0, num_blocks)`` for it. The *speculative* tail -- positions
        drafted ahead of a request's committed length, not yet verified --
        has no scheduler concept (no group is ever "ahead" of committed
        tokens), so it stays a small proposer-local reservation sized to the
        worst case: every concurrently active request drafting
        ``num_speculative_tokens`` positions at once. Zero without a draft
        model. See ``DraftModelProposer``'s split of committed vs. scratch
        block ids, and ``WorkerCachePlanner.setup_paged_attention`` for how
        this over-provisions the draft's *physical* backend beyond the
        scheduler-visible block count.
        """
        spec = self._runner.vllm_config.speculative_config
        if self._runner._draft_dims is None or spec is None:
            return 0
        block_size = self._runner.cache_config.block_size
        extra_per_req = cdiv(spec.num_speculative_tokens, block_size)
        return self._runner.scheduler_config.max_num_seqs * extra_per_req

    def draft_scratch_reserve_bytes(self) -> int:
        """Bytes held out of the KV budget for the draft's scratch tail.

        Subtracted before dividing by the (target + draft) combined
        per-block cost, so ``num_blocks`` leaves this much headroom in the
        draft's own physical pool without it being scheduler-visible or
        counted against the target's budget.
        """
        return (
            self.draft_scratch_reserve_blocks() * self._draft_cache_block_size_bytes()
        )

    def _draft_cache_block_size_bytes(self) -> int:
        """Byte size of one draft-model cache block, or 0 without a draft.

        Derived from the same ``FullAttentionSpec`` objects
        ``_draft_layer_specs`` registers with the scheduler
        (``page_size_bytes``), rather than a parallel hand-rolled
        formula, so the two cannot drift apart. Naturally 0 when no draft is
        configured, since ``_draft_layer_specs`` returns ``{}`` in that case.
        """
        block_size = self._runner.cache_config.block_size
        torch_dtype = MLX_TO_TORCH_DTYPE[self._require_kv_cache_dtype()]
        specs = self._draft_layer_specs(block_size=block_size, torch_dtype=torch_dtype)
        return sum(spec.page_size_bytes for spec in specs.values())

    def build_paged_attention_runtime(
        self, *, block_size: int
    ) -> PagedAttentionRuntime:
        """Create the paged-attention backend for the loaded model."""
        self._require_supported_per_layer_shapes()
        if self._runner.is_hybrid:
            return self._build_hybrid_backend()
        if self._runner.is_mla:
            return self._build_mla_backend(block_size)
        return self._build_sdpa_backend(block_size)

    def install_gemma4_mtp_kv_sharing(
        self,
        backend: PagedAttentionRuntime,
        *,
        block_size: int,
    ) -> None:
        """Wire Gemma4 MTP assistant layers to the target paged KV cache."""
        assistant = self._runner._gemma4_mtp_assistant
        if assistant is None:
            return
        if not isinstance(backend, SDPAPagedAttentionRuntime):
            raise NotImplementedError(
                "Gemma4 MTP assistant KV sharing requires the SDPA paged "
                "attention backend on Metal."
            )
        target_metadata = Gemma4MTPTargetMetadata.from_model_args(
            self._runner.model_args
        )
        self._runner._gemma4_mtp_assistant = assistant.with_target_kv_sharing(
            target_metadata=target_metadata,
            target_kv_cache=backend.kv_cache,
            block_size=block_size,
            group_block_sizes=backend.kv_group_block_sizes(),
        )

    def _build_hybrid_backend(self) -> HybridPagedAttentionRuntime:
        return HybridPagedAttentionRuntime(
            hybrid_plan=self._hybrid_plan(),
            dtype=self._require_kv_cache_dtype(),
            mamba_cache_mode=self._runner.cache_config.mamba_cache_mode,
        )

    def _build_mla_backend(self, block_size: int) -> MLAPagedAttentionRuntime:
        config = get_config()
        if config.turboquant:
            raise NotImplementedError(
                "TurboQuant is not supported for MLA models. "
                "Disable `turboquant` in --additional-config or select a "
                "non-MLA model."
            )
        return MLAPagedAttentionRuntime(
            num_layers=self._runner.num_layers,
            latent_dim=self._runner.mla_latent_dim,
            block_size=block_size,
            dtype=self._require_kv_cache_dtype(),
        )

    def _build_sdpa_backend(self, block_size: int) -> SDPAPagedAttentionRuntime:
        num_layers, cache_idx_map = self._cache_layer_mapping()
        config = get_config()
        kv_heads, head_dims = self._cache_layer_shapes(num_layers)
        # YOCO's ``build_yoco_cache_mapping`` assigns the first
        # ``num_cache_layers`` model layers identity-style (``mapping[i] = i``),
        # so slicing the first ``num_cache_layers`` entries of the full
        # per-model-layer list yields the correct window for each cache slot.
        # Shared layers then retrieve the right window via ``cache_idx_map``,
        # which points back to a same-type unique layer by construction.
        sw = self._runner.sliding_window_per_layer
        sw_list = sw[:num_layers] if sw is not None else None
        return SDPAPagedAttentionRuntime(
            num_layers=num_layers,
            num_kv_heads=self._runner.num_kv_heads,
            head_dim=self._runner.head_dim,
            block_size=block_size,
            dtype=self._require_kv_cache_dtype(),
            turboquant=config.turboquant,
            k_quant=config.k_quant if config.turboquant else None,
            v_quant=config.v_quant if config.turboquant else None,
            cache_idx_map=cache_idx_map,
            kv_heads_per_layer=kv_heads,
            head_dim_per_layer=head_dims,
            sliding_window_per_layer=sw_list,
        )

    def _cache_layer_shapes(self, num_cache_layers: int) -> tuple[list[int], list[int]]:
        """Build per-cache-layer ``(kv_heads, head_dim)`` lists.

        When the runner has per-layer shape lists, extract the first
        ``num_cache_layers`` entries (which correspond to the unique
        layers for YOCO models). Otherwise use the model's uniform shape
        for every cache layer.
        """
        kv_heads = self._runner.kv_heads_per_layer
        head_dims = self._runner.head_dim_per_layer
        if kv_heads is not None and head_dims is not None:
            return kv_heads[:num_cache_layers], head_dims[:num_cache_layers]
        return (
            [self._runner.num_kv_heads] * num_cache_layers,
            [self._runner.head_dim] * num_cache_layers,
        )

    def _require_supported_per_layer_shapes(self) -> None:
        """Reject unsupported per-layer KV shape combinations early."""
        kv_heads = self._runner.kv_heads_per_layer
        head_dims = self._runner.head_dim_per_layer
        if (kv_heads is None) != (head_dims is None):
            raise ValueError(
                "kv_heads_per_layer and head_dim_per_layer must be set together."
            )
        if kv_heads is None:
            return
        if get_config().turboquant:
            raise NotImplementedError(
                "TurboQuant with per-layer KV shapes is not yet supported."
            )
        if self._runner.is_hybrid:
            raise NotImplementedError(
                "Per-layer KV shapes with hybrid models require "
                "SDPA-layer index remapping, which is not yet implemented."
            )

    def _kv_layer_size_sum(self) -> int:
        """Sum of ``kv_heads × head_dim`` across KV cache layers.

        For uniform models this equals ``num_kv_layers × kv_heads × head_dim``.
        """
        num_kv_layers = self._num_kv_cache_layers()
        kv_heads = self._runner.kv_heads_per_layer
        head_dims = self._runner.head_dim_per_layer
        if kv_heads is not None and head_dims is not None:
            return sum(kv_heads[i] * head_dims[i] for i in range(num_kv_layers))
        return num_kv_layers * self._runner.num_kv_heads * self._runner.head_dim

    def _num_kv_cache_layers(self) -> int:
        if self._runner.is_hybrid:
            return self._hybrid_plan().layers.num_attention
        return self._runner.num_kv_cache_layers

    def _use_turboquant(self, config: MetalConfig) -> bool:
        # Hybrid models compress their SDPA layers too (see
        # ``_build_hybrid_backend``), so they must not be excluded here:
        # every scheduler-visible sizing path (specs, per-block bytes,
        # one-sequence estimates) has to agree with the runtime layout.
        return bool(config.turboquant and not self._runner.is_mla)

    def _kv_factor(self) -> int:
        return 1 if self._runner.is_mla else 2

    def _cache_layer_mapping(self) -> tuple[int, dict[int, int] | None]:
        if self._runner._yoco_cache_mapping is None:
            return self._runner.num_kv_cache_layers, None

        num_cache_layers, cache_idx_map = self._runner._yoco_cache_mapping
        logger.info(
            "YOCO KV sharing: %d unique cache layers (reduced from %d total)",
            num_cache_layers,
            self._runner.num_layers,
        )
        return num_cache_layers, cache_idx_map

    def _require_kv_cache_dtype(self) -> mx.Dtype:
        if self._runner.kv_cache_dtype is None:
            raise RuntimeError("KV cache dtype not initialized; load_model() first")
        return self._runner.kv_cache_dtype


class WorkerCachePlanner:
    """Worker-owned cache budgeting and paged-attention setup."""

    def __init__(self, worker: MetalWorker) -> None:
        self._worker = worker

    def setup_paged_attention(self, *, overhead: int) -> None:
        """Allocate paged KV cache and patch the loaded model."""
        self._worker.model_runner.validate_paged_attention_support()
        plan = self._paged_attention_plan(overhead=overhead)
        logger.info(
            "Paged attention memory breakdown: "
            "%s, per_block_bytes=%d, "
            "num_blocks=%d, max_tokens_cached=%d",
            plan.format_breakdown(),
            plan.per_block_bytes,
            plan.num_blocks,
            plan.num_blocks * plan.block_size,
        )

        backend = self._worker.model_runner.build_paged_attention_runtime(
            block_size=plan.block_size
        )
        backend.initialize(plan.num_blocks)
        self._worker.model_runner.install_gemma4_mtp_kv_sharing(
            backend,
            block_size=plan.block_size,
        )
        n_patched = backend.patch_model(self._worker.model_runner.model)
        self._worker.model_runner.install_drafter(
            num_blocks=plan.num_blocks,
            block_size=plan.block_size,
        )
        config = get_config()

        try_enable_gemma4_yoco_fast_prefill(
            self._worker.model_runner.model,
            self._worker.model_runner.model_args,
            num_paged_layers=n_patched,
        )
        logger.info(
            "Paged attention enabled: %d layers patched, "
            "%d blocks allocated (block_size=%d, mla=%s, turboquant=%s, k_quant=%s)",
            n_patched,
            plan.num_blocks,
            plan.block_size,
            self._worker.model_runner.is_mla,
            config.turboquant,
            config.k_quant if config.turboquant else "N/A",
        )

        self._worker.model_runner.install_paged_attention_runtime(
            backend,
            block_size=plan.block_size,
        )

    def get_model_memory_usage(self) -> int:
        """Return current model memory usage in bytes."""
        mx.eval(mx.array([0]))
        return mx.get_active_memory()

    def determine_available_memory(self) -> int:
        """Return scheduler-visible available cache memory."""
        mode = self._worker.model_runner.scheduler_memory_reporting_mode()

        if mode == "stt_nominal":
            logger.info("STT model: reporting nominal memory for scheduler")
            return STT_SCHED_AVAILABLE_BYTES

        if mode == "paged_attention_capacity":
            overhead = self._worker.model_runner.profile_run()
            self.setup_paged_attention(overhead=overhead)
            backend = self._worker.model_runner.paged_attention_runtime
            if backend is None:
                raise RuntimeError(
                    "Paged attention backend not initialized for capacity reporting"
                )
            block_size_bytes = self._worker.get_cache_block_size_bytes()
            available = backend.num_blocks() * block_size_bytes
            logger.info(
                "Paged attention: reporting MPS cache capacity "
                "(%d blocks × %d bytes = %.2f GB)",
                backend.num_blocks(),
                block_size_bytes,
                available / 1e9,
            )
            return available

        if mode == "paged_attention_layout_budget":
            overhead = self._worker.model_runner.profile_run()
            budget = self.base_kv_budget_bytes(
                metal_limit=self._metal_limit_bytes(),
                fraction=self._memory_fraction(),
                model_memory=self.get_model_memory_usage(),
                overhead=overhead,
            )
            budget -= self._worker.model_runner.draft_scratch_reserve_bytes()
            logger.info(
                "Upstream cache layout: reporting %.2f GB KV budget; "
                "runtime allocation deferred until vLLM KVCacheConfig",
                budget / 1e9,
            )
            return budget

        if mode == "pooling_no_kv":
            self._worker.model_runner.profile_run()
            logger.info("Encoder pooling: reporting zero KV-cache bytes")
            return 0

        raise AssertionError(f"Unknown scheduler memory reporting mode: {mode}")

    @staticmethod
    def base_kv_budget_bytes(
        metal_limit: int,
        model_memory: int,
        fraction: float,
        overhead: int,
    ) -> int:
        """Return cache bytes after model weights and execution overhead."""
        return int(metal_limit * fraction) - model_memory - overhead

    def _paged_attention_plan(
        self, *, overhead: int, require_min_blocks: bool = True
    ) -> _PagedAttentionPlan:
        block_size = self._worker.vllm_config.cache_config.block_size
        fraction = self._memory_fraction()
        metal_limit = self._metal_limit_bytes()
        model_memory = self.get_model_memory_usage()
        per_block_bytes = self._worker.get_cache_block_size_bytes()
        usable_metal = int(metal_limit * fraction)
        base_kv_budget = self.base_kv_budget_bytes(
            metal_limit,
            model_memory,
            fraction,
            overhead,
        )
        draft_scratch_bytes = self._worker.model_runner.draft_scratch_reserve_bytes()
        kv_budget = base_kv_budget - draft_scratch_bytes
        plan = _PagedAttentionPlan(
            block_size=block_size,
            fraction=fraction,
            metal_limit=metal_limit,
            usable_metal=usable_metal,
            model_memory=model_memory,
            overhead=overhead,
            per_block_bytes=per_block_bytes,
            base_kv_budget=base_kv_budget,
            kv_budget=kv_budget,
            num_blocks=max(0, kv_budget // per_block_bytes),
        )
        self._validate_paged_attention_plan(
            plan,
            require_min_blocks=require_min_blocks,
        )
        return plan

    def _validate_paged_attention_plan(
        self, plan: _PagedAttentionPlan, *, require_min_blocks: bool
    ) -> None:
        if plan.kv_budget <= 0:
            raise ValueError(
                "Paged attention: not enough Metal memory for KV cache. "
                f"{plan.format_breakdown()}. {plan.format_mitigations()}"
            )

        if require_min_blocks and plan.num_blocks < PAGED_ATTENTION_MIN_BLOCKS:
            raise ValueError(
                "Paged attention: computed num_blocks too low "
                f"({plan.num_blocks} < minimum {PAGED_ATTENTION_MIN_BLOCKS}). "
                f"{plan.format_breakdown()}, "
                f"per_block_bytes={plan.per_block_bytes}. "
                f"{plan.format_mitigations()}"
            )

    def _memory_fraction(self) -> float:
        """Resolve the paged KV memory fraction from ``--gpu-memory-utilization``."""
        fraction = self._worker.vllm_config.cache_config.gpu_memory_utilization
        logger.info(
            "Paged attention: using --gpu-memory-utilization=%.2f",
            fraction,
        )
        return fraction

    def _metal_limit_bytes(self) -> int:
        device_info = mx.device_info()
        metal_limit = int(device_info.get("max_recommended_working_set_size", 0))
        if metal_limit <= 0:
            raise RuntimeError(
                "Paged attention: mx.device_info() did not return "
                "max_recommended_working_set_size. "
                "Ensure MLX is up to date and running on Apple Silicon. "
                f"Reported device_info keys: {list(device_info.keys())}"
            )
        return metal_limit
