# Gate A run record

- Operator authorised Part A after confirming the branch was pushed. Part B and the live worker are excluded.
- Fresh clone at `/Users/daniel/Developer/EuroEval-2310`, branch `feat/2310-apple-gpu-worker`, commit `cc594abe4203db850d9edd9216596a1834d2a87e`. This commit changes only `pyproject.toml` and `uv.lock` for the Darwin pin bump.
- Tested pair is vLLM/vllm-metal v0.30.0/v0.30.0. The operator's supplied pin rationale is preserved verbatim in `required-pin-rationale.md` for insertion immediately after the report's pins line.
- Initial `make install` failed copying a pack file inside uv's local Git cache. An unchanged retry completed. No lock-resolution failure, lock edit, prerequisite fix, or commit was needed.
- `npm install` rewrote `package-lock.json` during installation. Its generated diff is preserved in `install-package-lock.diff`; the fresh clone's tracked lockfile was restored to the tested commit.
- The new run brief's harness was adapted only in `/tmp`: footprint collection runs in one independent thread, with each call capped at 3 seconds and a maximum of six PIDs. The safety loop does not wait for it. This resolves the previously identified sequential-footprint delay. Raw byte footprints are retained for exact unit conversion.
- The harness checks pressure and swap before scheduling footprint work, refuses baseline pressure >=2, stops at the first sampled pressure 4 or swap increase >1024 MiB, and records results on cancellation. It reaps the root during INT/TERM/KILL group cleanup. Individual runs are bounded at one hour; this Gate A pass is bounded at three hours of evaluation work before reporting remaining rows unproven.
- A local cancellation smoke check started a root and child sleep process, signalled the harness PID, recorded `operator signal 2`, and left no owned PIDs.
- No Step 0 scripts were reused. No legacy Metal fraction is passed to evaluation children. The guard harness explicitly removes an inherited legacy fraction if present.
- `u.json` is computed once from a fresh no-evaluation snapshot and reused throughout. No other EuroEval engine was observed; unrelated user applications, including oMLX, were left intact. The formula accounts for their measured host-memory use.
- The implementation plan file was not present in this checkout or the available attachments. The supplied run brief, the operator's update, current source, and the existing issue context provide the execution contract.
- No authoritative Sol allowance counter is exposed. Exact percentage use cannot be monitored; work is limited to this bounded local experiment and evidence handoff.

- A1 exited 1 during engine startup with a missing prebuilt native extension. Guard stop reason was null, pressure stayed 1, swap growth was 0 MiB, and no owned process survived. Runtime logged CLI utilisation 0.48 after rounding the requested 0.4796. The strict runtime metal_limit log criterion was not established before failure.
- Part A stopped at A1 as required. A2-A4 were not run. The A5 reduced feature reproduction was not triggered because A1 did not pass. No source-build flag, wheel substitution, dependency edit, backend patch, broker run, commit, or push was attempted.
